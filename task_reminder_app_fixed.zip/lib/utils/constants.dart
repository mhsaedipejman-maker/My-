import 'package:flutter/material.dart';

class AppColors {
  static const ink = Color(0xFF12313A); static const muted = Color(0xFF52656B); static const canvas = Color(0xFFF5F7F7); static const surface = Color(0xFFFFFFFF); static const teal = Color(0xFF007C83); static const tealDark = Color(0xFF005B61); static const line = Color(0xFFD8E1E2); static const low = Color(0xFF167447); static const medium = Color(0xFF9A5700); static const high = Color(0xFFB3261E);
}
const double radiusCard = 8; const double radiusDialog = 12; const double space = 8;
Color priorityColor(String p) => p == 'high' ? AppColors.high : p == 'medium' ? AppColors.medium : AppColors.low;
