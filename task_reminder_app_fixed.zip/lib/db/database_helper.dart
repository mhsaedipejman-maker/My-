import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/task.dart';
class DatabaseHelper {
  DatabaseHelper._(); static final instance=DatabaseHelper._(); Database? _db;
  Future<Database> get db async => _db ??= await _open();
  Future<Database> _open() async { final path=join(await getDatabasesPath(),'tasks.db'); return openDatabase(path,version:1,onCreate:(d,v)=>d.execute('CREATE TABLE tasks (id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,description TEXT,due_date INTEGER NOT NULL,priority TEXT NOT NULL,image_path TEXT,done INTEGER NOT NULL DEFAULT 0)')); }
  Future<List<Task>> all() async { final rows=await (await db).query('tasks',orderBy:'due_date ASC'); return rows.map(Task.fromMap).toList(); }
  Future<int> insert(Task t)=>db.then((d)=>d.insert('tasks',t.toMap()..remove('id')));
  Future<void> update(Task t)=>db.then((d)=>d.update('tasks',t.toMap(),where:'id=?',whereArgs:[t.id]));
  Future<void> delete(int id)=>db.then((d)=>d.delete('tasks',where:'id=?',whereArgs:[id]));
}
