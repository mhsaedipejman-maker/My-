class Task {
  final int? id; final String title, description, priority; final DateTime dueDate; final String? imagePath; final bool done;
  const Task({this.id, required this.title, required this.description, required this.dueDate, required this.priority, this.imagePath, this.done=false});
  Task copyWith({int? id,String? title,String? description,DateTime? dueDate,String? priority,String? imagePath,bool? done}) => Task(id:id??this.id,title:title??this.title,description:description??this.description,dueDate:dueDate??this.dueDate,priority:priority??this.priority,imagePath:imagePath??this.imagePath,done:done??this.done);
  Map<String,Object?> toMap()=>{'id':id,'title':title,'description':description,'due_date':dueDate.millisecondsSinceEpoch,'priority':priority,'image_path':imagePath,'done':done?1:0};
  factory Task.fromMap(Map<String,Object?> m)=>Task(id:m['id'] as int,title:m['title'] as String,description:(m['description'] as String?)??'',dueDate:DateTime.fromMillisecondsSinceEpoch(m['due_date'] as int),priority:m['priority'] as String,imagePath:m['image_path'] as String?,done:(m['done'] as int)==1);
}
