import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

import '../models/task.dart';

class NotificationService {
  NotificationService._();
  static final instance = NotificationService._();

  final FlutterLocalNotificationsPlugin plugin =
      FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  Future<void> init() async {
    if (_initialized) return;
    tz.initializeTimeZones();
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    await plugin.initialize(
      const InitializationSettings(android: android),
    );
    final androidPlugin = plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.createNotificationChannel(
      const AndroidNotificationChannel(
        'task_reminders',
        'Task reminders',
        description: 'Scheduled task reminders',
        importance: Importance.high,
      ),
    );
    await androidPlugin?.requestNotificationsPermission();
    _initialized = true;
  }

  Future<void> schedule(Task task) async {
    if (task.id == null || task.done || !task.dueDate.isAfter(DateTime.now())) {
      return;
    }
    await cancel(task.id!);
    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        'task_reminders',
        'Task reminders',
        channelDescription: 'Scheduled task reminders',
        importance: Importance.high,
        priority: Priority.high,
      ),
    );
    final scheduledDate = tz.TZDateTime.from(task.dueDate, tz.local);
    try {
      await plugin.zonedSchedule(
        task.id!,
        task.title,
        task.description.isEmpty ? 'Task due now' : task.description,
        scheduledDate,
        details,
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        payload: '${task.id}',
      );
    } on Exception {
      // Exact alarms can be disabled by the user on Android 12+.
      await plugin.zonedSchedule(
        task.id!,
        task.title,
        task.description.isEmpty ? 'Task due now' : task.description,
        scheduledDate,
        details,
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        payload: '${task.id}',
      );
    }
  }

  Future<void> cancel(int id) => plugin.cancel(id);
}
