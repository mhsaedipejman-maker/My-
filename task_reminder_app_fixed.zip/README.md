# Task Reminder

A Flutter Android task manager with SQLite persistence, scheduled local notifications, optional camera/gallery images, priorities, and charts.

## Run
1. Install Flutter (3.19+ recommended) and Android Studio/SDK.
2. `flutter pub get`
3. `flutter run`
4. `flutter build apk --release` creates `build/app/outputs/flutter-apk/app-release.apk`.

Android 13+ notification permission is requested at runtime. Exact alarms may require enabling **Alarms & reminders** in Android settings on Android 12+. If exact-alarm access is denied, Android may deliver reminders inexactly.

Tasks and image paths are stored locally on the device; deleting the app removes its database. Notifications are scheduled again when tasks are saved and canceled on deletion/completion. The app does not upload data.
